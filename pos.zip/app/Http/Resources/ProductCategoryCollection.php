<?php

namespace App\Http\Resources;

/**
 * Class ProductCategoryCollection
 */
class ProductCategoryCollection extends BaseCollection
{
    public $collects = ProductCategoryResource::class;
}
