<?php

namespace App\Http\Resources;

/**
 * Class TransferResource
 */
class TransferResource extends BaseJsonResource
{

}
