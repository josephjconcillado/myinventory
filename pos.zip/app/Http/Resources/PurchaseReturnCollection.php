<?php

namespace App\Http\Resources;

/**
 * Class ExpenseCategoryCollection
 */
class PurchaseReturnCollection extends BaseCollection
{
    public $collects = PurchaseReturnResource::class;
}
