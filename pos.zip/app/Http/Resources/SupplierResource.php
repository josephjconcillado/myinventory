<?php

namespace App\Http\Resources;

/**
 * Class SupplierResource
 */
class SupplierResource extends BaseJsonResource
{

}
