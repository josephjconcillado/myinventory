<?php

namespace App\Http\Resources;

/**
 * Class SettingCollection
 */
class SettingCollection extends BaseCollection
{
    public $collects = SettingResource::class;
}
