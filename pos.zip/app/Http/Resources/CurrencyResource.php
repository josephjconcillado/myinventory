<?php

namespace App\Http\Resources;

/**
 * Class CurrencyResource
 */
class CurrencyResource extends BaseJsonResource
{

}
