<?php

namespace App\Http\Resources;

/**
 * Class QuotationCollection
 */
class QuotationCollection extends BaseCollection
{
    public $collects = QuotationResource::class;
}
